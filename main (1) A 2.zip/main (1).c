/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main ()
{
int num1 = 0,  num2 = 0, suma = 0, resta = 0, multiplicacion = 0;
float divicion = 0.0;

printf ("ingresa el primer numero: ") ;
scanf ("%d" ,  &num1) ;
printf ("ingresa el segundo numero: ") ;
scanf ("%d" , &num2) ;

printf ("La suma de ambos numeros es %d \n" , suma = num1 + num2) ;
printf ("La resta de ambos numeros es %d \n" , resta = num1 - num2) ;
printf ("La multiplicacion de ambos numeros es %d \n" , multiplicacion =num1 * num2) ;
printf ("La division de ambos numeros es %f \n" , divicion = num1 / num2) ;
return 0;
}


