/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main ()
{
int paterno = 0,  materno = 0, nombre = 0, dia = 0, mes = 0;
float año = 0;

printf ("apellido paterno: ") ;
scanf ("%d" ,  &paterno) ;
printf ("apellido materno: ") ;
scanf ("%d" , &materno) ;
printf ("nombre: ") ;
scanf ("%d" ,  &nombre) ;
printf ("dia : ") ;
scanf ("%d" , &dia) ;
printf ("mes : ") ;
scanf ("%d" ,  &mes ) ;
printf ("año : ") ;
scanf ("%d" , &año) ;

printf ("rfc %d \n" , paterno =  + materno + nombre + dia + mes + año) ;

return 0;

}
