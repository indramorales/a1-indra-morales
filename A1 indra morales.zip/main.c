/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main ()
{
    
int edad = 0, mayoria = 17;

printf("programa que determina si es mayor de edad o no \n\n");
printf("proporcionarme tu edad: ");
scanf("%d" , &edad );

if(edad >= mayoria)
printf("si, eres mayor de edad \n");
else 
printf("no eres mayor \n");
return 0;
}